// external Javascript which is to be included in the html file

//window.addEventListener('load',(e)=>{
//window.addEventListener('DOMContentLoaded', function(){
//     console.log('Dom loaded successfully');

if (document.readyState !== 'loading') {
    console.log('Document Loadded successfully');
    fullCode();

} else {
    document.addEventListener('DOMContentLoaded', function () {
        console.log('Document Loading ');
        fullCode();

    });
}


// Section 1 : Alert 
function fullCode() {
    document.getElementById('sec1-btn1').addEventListener("click", alert_showmsg);
    function alert_showmsg() {
        let textmsg = document.getElementById("sec1-input").value;
        if (textmsg.trim() == '') {
            alert("No alert text has been entered!");
            console.log('Either a space or no text has been entered');
            return;
        }
        else {
            alert(textmsg);
            console.log(`The alert is ${textmsg}`);

        }
        // clear the text in the alert box
        document.getElementById("sec1-input").value = "";

    }



    // Section 2: Change the appearance of the box with selections with the HTML and attributes
    document.getElementById('sec2-btn1').addEventListener('click', function () {

        let c = document.getElementById('sec2-contentarea').childNodes;
        console.log(c);
        document.getElementById('sec2-contentarea').childNodes[1].innerHTML = "<h3>Sonita Bose</h3>";
        document.getElementById('sec2-box').style.backgroundColor = "#888888";
        document.getElementById('sec2-box').style.width = "100%";
        document.getElementById('sec2-box').style.height = "20px";
        document.getElementById('sec2-contentarea').childNodes[5].style = "font-weight:bold ; font-style: italic";
        document.getElementById('sec2-contentarea').childNodes[5].style.fontSize = "12px";
        document.getElementById('sec2-contentarea').childNodes[7].src = 'img/hamburger_color_icon.png';
        document.getElementById('sec2-contentarea').childNodes[7].alt = "Color_Hamburger_Icon";
        document.getElementById('sec2-contentarea').childNodes[7].style.width = "100px";
        document.getElementById('sec2-contentarea').childNodes[10].href = "https://www.iit.edu/";
        document.getElementById('sec2-contentarea').childNodes[10].innerHTML = "Illinois Tech Website";
        document.getElementById('sec2-contentarea').childNodes[10].style.color = "#cc0000";
        document.getElementById('sec2-contentarea').childNodes[10].style.textDecoration = "underline";
        console.log('All properties added');
    }, false);


    //Section 3 Temperature Conversion

    tempconversion = document.getElementById('sec3-btn1').addEventListener("click", temperature);
    function temperature() {
        let inputVal = document.getElementById("sec3-input").value;

        if (inputVal.trim() == "") {
            alert("No value has been entered!");
            console.log('Either a space or no text has been entered');
            return;
        }

        else if (!Number(inputVal)) {
            alert("A non-numeric value is entered!");
            console.log('AlphaNumeric Entered or non numeric');
            return;
        }

        else {
            inputVal = parseFloat(document.getElementById("sec3-input").value);

        }

        inputVal = parseFloat(document.getElementById("sec3-input").value);
        let fahrenheit = 32 + (inputVal * (9 / 5));
        // used the \u00B0 to display the degree symbol 
        document.getElementById("sec3-contentarea").innerHTML = ("<p>" + inputVal + " \u00B0C degrees celsius is equal to " + fahrenheit + " degress fahrenheit </p>");
        // to clear the value from the box
        document.getElementById("sec3-input").value = "";
        console.log(`The temperature converted is${fahrenheit}`)
    }

    clearSec3 = document.getElementById('sec3-btn2').addEventListener("click", cleanbox);
    function cleanbox() {
        document.getElementById("sec3-contentarea").innerHTML = "";
        console.log('All text in the box has been cleared')
    };

    //Section 4 The coloured boxes 

    function color_display() {
        let content = document.getElementById("sec4-contentarea");
        let quantity = document.getElementById("sec4-input1");
        let colour = document.getElementById("sec4-select1");
        

        if (quantity.value.trim() == "") {
            alert("No value has been entered!");
            console.log('NO value or empty value has been entered');
            return;
        }

        else if (!Number(quantity.value)) {
            alert("A non-numeric value is entered!");
            console.log('A non-numeric value was entered');
            return;
        }


        let squarecount = Number(quantity.value);
        for (var i = 1; i <= squarecount; i++) {
            let square = document.createElement('div');
            square.style.height = "60px";
            square.style.width = "60px";
            square.style.margin = "5px";
            square.style.display = "inline-block";
            square.style.cursor = 'pointer';
            square.style.backgroundColor = colour.value;
            square.addEventListener('click', delete_square, false);
            content.append(square);
            console.log('Box added!');
        }
    }

    function delete_square() {
        console.log('Box removed!');
        this.remove();
        
    }

    function cleanarea() {
        console.log('Box cleared!');
        document.getElementById("sec4-contentarea").innerHTML = "";
    }

    document.getElementById("sec4-btn1").addEventListener("click", color_display, false);
    
    document.getElementById("sec4-btn2").addEventListener("click", cleanarea, false);
    





    //Section 5
    let keyPress;
    keyPress = document.createElement("span"); //The <span> tag is an inline container used to mark up a part of a text
    document.getElementById('sec5-input').addEventListener('keyup', keyboard, false);

    function keyboard(e) {

        // $('input').on('keydown', function(e) {
        //   console.log(e.key);

        //alert(String.fromCharCode(evt.keyCode));
        let keyClick = e.key;
        console.log(keyClick);
        keyPress.style.fontSize = '60px';
        keyPress.style.fontWeight = 'bold';
        // The innerText property sets or returns the text content of the specified node
        keyPress.innerText = keyClick;
        document.getElementById('sec5-contentarea').appendChild(keyPress);
        document.getElementById('sec5-input').value = "";
        console.log('key pressed value printed');
        if (e.code == "Space") {
            keyPress.innerHTML = "space";
            document.getElementById('sec5-contentarea').innerHTML = "";
            document.getElementById('sec5-contentarea').appendChild(keyPress);
            console.log("Space bar keypressed!")
        }

    }

    document.getElementById('sec5-input').addEventListener('keydown', disappear, false);
    function disappear() {
        keyPress.remove();
    }



    //Section 6 implementation 1 

    document.getElementById('sec6-btn1').addEventListener('click', function (ajaxf) {
        console.log('Get Data button Clicked!');
        fetch('https://jsonplaceholder.typicode.com/users')
            .then(response => response.json())
            .then(json => {
                let list = document.createElement('ul');
                for (let i = 0; i < json.length; i++) {
                    const element = json[i];
                    let item = document.createElement('li');
                    let text = element.name + ', ' + element.email;
                    item.appendChild(document.createTextNode(text));
                    list.appendChild(item);
                }
                document.getElementById('sec6-contentarea').appendChild(list);
                document.getElementById('sec6-btn1').disabled = true;
            });

    }, false);

    document.getElementById('sec6-btn2').addEventListener("click", function (clearajax1) {
        console.log('Data cleared');
        document.getElementById("sec6-contentarea").innerHTML = "";
        document.getElementById('sec6-btn1').disabled = false;
    }, false);




    //Section 7 implementation 2 

    document.getElementById('sec7-btn1').addEventListener('click', function (evt) {
        let list = document.createElement('ul');
        let xhtr = new XMLHttpRequest(); //Creating an XML request
        console.log('Get Data button Clicked!');
        console.log(evt);
        xhtr.onreadystatechange = function () {
            if (xhtr.readyState === 4 && xhtr.status === 200) {
                let responseJson = JSON.parse(xhtr.responseText); // contains entire data 

                for (let i = 0; i < responseJson.length; i++) {
                    const element = responseJson[i]; //element contains each node of the json
                    let item = document.createElement('li');
                    let text = element.name + ', ' + element.email; // retreiving name and email
                    item.appendChild(document.createTextNode(text));
                    list.appendChild(item);
                }
            }
            document.getElementById('sec7-contentarea').appendChild(list);
        }



        xhtr.open('GET', 'https://jsonplaceholder.typicode.com/users', true);
        xhtr.send();
        document.getElementById('sec7-btn1').disabled = true;
    }, false);


    document.getElementById('sec7-btn2').addEventListener("click", function (clearajax2) {
        console.log('Data cleared');
        document.getElementById("sec7-contentarea").innerHTML = "";
        document.getElementById('sec7-btn1').disabled = false;
    }, false);


}